package com.nhnacademy;

public class History {
    int fightCount;
    int win;
    
}
