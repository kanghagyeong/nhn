package com.nhnacademy;

public class ChangeHistory {
    
}
