package com.nhnacademy;

public interface Breakable {
    public void breakBox();
}
