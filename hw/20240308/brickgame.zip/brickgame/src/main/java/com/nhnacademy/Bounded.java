package com.nhnacademy;

import java.awt.Rectangle;

public interface Bounded {
   
    public void bounce(Regionable other);
    
}
